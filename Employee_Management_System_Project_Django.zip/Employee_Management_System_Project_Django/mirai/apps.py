from django.apps import AppConfig


class MiraiConfig(AppConfig):
    name = 'mirai'
